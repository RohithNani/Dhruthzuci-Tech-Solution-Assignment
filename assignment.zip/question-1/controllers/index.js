exports.symbolsMark = (req, res, next) => {
  const { chemicals, symbols } = req.body;
  var result = [];
  for (var i = 0; i < chemicals.length; i++) {
    var chemical = chemicals[i];
    for (var j = 0; j < symbols.length; j++) {
      if (chemical.includes(symbols[j]))
        result.push(chemical.replace(symbols[j], '[' + symbols[j] + ']'));
    }
  }
  res.json({ result: result });
};
