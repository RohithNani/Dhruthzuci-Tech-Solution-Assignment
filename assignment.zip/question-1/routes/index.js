var express = require('express');
var router = express.Router();

const indexController = require('../controllers/index');

router.post('/find_symbols_in_names', indexController.symbolsMark);

module.exports = router;
